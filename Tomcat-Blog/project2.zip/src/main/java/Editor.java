import java.io.IOException;
import java.sql.* ;
import java.util.List;
import java.util.ArrayList;
import java.util.Date;
import java.util.Calendar;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import java.io.PrintWriter;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import org.commonmark.node.*;
import org.commonmark.parser.Parser;
import org.commonmark.renderer.html.HtmlRenderer;


/**
 * Servlet implementation class for Servlet: ConfigurationTest
 *
 */
public class Editor extends HttpServlet {
    /**
     * The Servlet constructor
     *
     * @see javax.servlet.http.HttpServlet#HttpServlet()
     */
    public Editor() {}

    String use = null;
    int post = 0;

    public void init() throws ServletException
    {
        //Open DB connection here
        /*  write any servlet initialization code here or remove this function */
        /* load the driver */
        try {
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException ex) {
            System.out.println(ex);
            return;
        }
        //request.getRequestDispatcher("/home.jsp").forward(request, response);
    }

    /**
     * Handles HTTP GET requests
     *
     * @see javax.servlet.http.HttpServlet#doGet(HttpServletRequest request,
     *      HttpServletResponse response)
     */
    public void doGet(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException
    {
      //Get parameters
      String action = request.getParameter("action");
      String postid = request.getParameter("postid");
      String title = request.getParameter("title");
      String body = request.getParameter("body");
      String username = request.getParameter("username");

      boolean newPost;

      if (request.getParameter("username") != null) {
        use = request.getParameter("username");
      }
      if (request.getParameter("postid") != null) {
        post = Integer.parseInt(request.getParameter("postid"));
      }

      request.setAttribute("username", use);
      request.setAttribute("postid", post);


      if (request.getParameter("Preview") != null) {

          Parser parser = Parser.builder().build();
          HtmlRenderer renderer = HtmlRenderer.builder().build();
          String html_title = renderer.render(parser.parse(title));
          String html_body = renderer.render(parser.parse(body));

          request.setAttribute("username", request.getParameter("username"));
          request.setAttribute("title", html_title);
          request.setAttribute("body", html_body);
          request.setAttribute("username", use);
          request.getRequestDispatcher("/preview.jsp").forward(request, response);
        }
        else if (request.getParameter("Close") != null) {
          request.setAttribute("use", use);
          request.getRequestDispatcher("/home.jsp").forward(request, response);
        }
        else if (request.getParameter("Save") != null) {
          doPost(request, response);
        }
        else if (request.getParameter("NewPost") != null) {
          request.setAttribute("username", use);
          request.setAttribute("post", post);
          newPost = true;
          request.setAttribute("NewPost", newPost);
          request.getRequestDispatcher("/edit.jsp").forward(request, response);
        }
        else if (request.getParameter("Delete") != null) {
          request.setAttribute("use", use);
          request.getRequestDispatcher("/home.jsp").forward(request, response);
        }
        else if (request.getParameter("DeleteHome") != null) {
          doPost(request, response);
        }
        else if (request.getParameter("Open") != null) {
          request.setAttribute("username", use);
          request.setAttribute("post", post);
          newPost = false;
          request.setAttribute("NewPost", newPost);
          request.getRequestDispatcher("/edit.jsp").forward(request, response);
        }


        if (request.getParameter("action") != null) {
          String param = request.getParameter("action");

          if (param.equals("open")) {
            request.setAttribute("username", use);
            request.setAttribute("post", post);
            newPost = false;
            request.setAttribute("NewPost", newPost);
            request.getRequestDispatcher("/edit.jsp").forward(request, response);
          }
          else if (param.equals("save")) {
            doPost(request, response);
          }
          else if (param.equals("preview")) {

            Parser parser = Parser.builder().build();
            HtmlRenderer renderer = HtmlRenderer.builder().build();
            String html_title = renderer.render(parser.parse(title));
            String html_body = renderer.render(parser.parse(body));

            request.setAttribute("username", request.getParameter("username"));
            request.setAttribute("title", html_title);
            request.setAttribute("body", html_body);
            request.setAttribute("username", use);
            request.getRequestDispatcher("/preview.jsp").forward(request, response);
          }
          else if (param.equals("delete")) {
            doPost(request, response);
          }
          else if (param.equals("list")) {
            request.setAttribute("use", use);
            request.getRequestDispatcher("/home.jsp").forward(request, response);
          }
        }

      //request.getRequestDispatcher("/home.jsp").forward(request, response);
  }



    /**
     * Handles HTTP POST requests
     *
     * @see javax.servlet.http.HttpServlet#doPost(HttpServletRequest request,
     *      HttpServletResponse response)
     */
    public void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException
    {

      String action = request.getParameter("action");
      String title = request.getParameter("title");
      String body = request.getParameter("body");

      Connection c = null;
      Statement  s = null;

      try {
        /* create an instance of a Connection object */
        c = DriverManager.getConnection("jdbc:mysql://localhost:3306/CS144", "cs144", "");

      } catch (SQLException ex) {
        PrintWriter out = response.getWriter();
        out.println("<!DOCTYPE html>");
        out.println("<html>");
        out.println("<body>" + ex.getMessage() + "<br>");
        out.println("</html>");
        out.close();
      }

      //If saved clicked
      if (request.getParameter("Save") != null) {

        try {
          String username1, title1, body1;
          int postid1;
          int update = 0;
          /* create an instance of a Connection object */

          //Calendar calendar = Calendar.getInstance();
          //java.sql.Date startDate = new java.sql.Date(calendar.getTime().getTime());
          DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
          Date date = new Date();
          String created = dateFormat.format(date);


          String get_postid = "SELECT * from Data WHERE username = ?";
          PreparedStatement prepared1 = c.prepareStatement(get_postid);
          prepared1.setString(1, use);

          ResultSet rs = prepared1.executeQuery();

          if (!rs.next()) {
            String insert = "INSERT INTO Data (username, postid)" + " values (?,?)";
            PreparedStatement prepared = c.prepareStatement(insert);

            prepared.setString(1, use);
            prepared.setInt(2, 0);
            prepared.execute();
          }
          else {
            //if (rs.next() != false) {
            int post = rs.getInt("postid");
            update = post += 1;

            String insert = "UPDATE Data SET postid = ? WHERE username = ?";
            PreparedStatement prepared = c.prepareStatement(insert);
            prepared.setInt(1, update);
            prepared.setString(2, use);
            prepared.execute();
          }

          String insert = "INSERT INTO Posts (username, postid, title, body, modified, created)" + " values (?,?,?,?,?,?)";
          PreparedStatement prepared = c.prepareStatement(insert);

          //postid1 = request.getParameter("postid");
          //username1 = request.getParameter("username");

          prepared.setString(1, use);
          prepared.setInt(2, update);
          prepared.setString(3, title);
          prepared.setString(4, body);
          prepared.setString(5, created);
          prepared.setString(6, created);

          prepared.execute();

        } catch (SQLException ex) {

          PrintWriter out = response.getWriter();
          out.println("<!DOCTYPE html>");
          out.println("<html>");
          out.println("<body>" + ex.getMessage() + "<br>");
          out.println("</html>");
          out.close();
        }

        request.setAttribute("use", use);
        request.getRequestDispatcher("/home.jsp").forward(request, response);
      }
      else if (request.getParameter("DeleteHome") != null) {

        try {
          //Print out home screen with data

          String display = "DELETE FROM Posts WHERE username = ? AND postid = ?";
          PreparedStatement prepared = c.prepareStatement(display);

          prepared.setString(1, use);
          prepared.setInt(2, post);

          prepared.executeUpdate();
        } catch (SQLException ex) {
          System.out.println(ex.getMessage());
        }

        request.setAttribute("use", use);
        request.getRequestDispatcher("/home.jsp").forward(request, response);
      }
    }
  }
